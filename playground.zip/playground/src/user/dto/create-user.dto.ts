export class CreateUserDto {
  email: string;
  name?: string;
}
