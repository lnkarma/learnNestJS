import { Test, TestingModule } from '@nestjs/testing';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UserService } from './user.service';

describe('UserService', () => {
  let service: UserService;
  let prismaService: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [UserService, PrismaService],
    }).compile();

    service = module.get<UserService>(UserService);
    prismaService = module.get<PrismaService>(PrismaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('Create user', () => {
    const createUserDto: CreateUserDto = {
      email: 'test@example.com',
    };

    it('should create a user', async () => {
      const user = {
        id: 123,
        name: null,
        ...createUserDto,
      };
      prismaService.user.create = jest.fn().mockResolvedValueOnce(user);
      const result = await service.create(createUserDto);
      expect(prismaService.user.create).toHaveBeenCalledWith({
        data: { ...createUserDto },
      });
      expect(result.email).toBe(createUserDto.email);
    });
  });
});
